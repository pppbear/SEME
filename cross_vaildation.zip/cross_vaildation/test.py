import pandas as pd
import numpy as np
from sklearn.linear_model import LinearRegression
from itertools import combinations

# 1. 读取数据
file = 'shanghai_data.xlsx'  # 路径根据实际情况调整
df = pd.read_excel(file)

# 2. 先将原始列转为数值型
base_cols = ['Land01', 'Land02', 'Land03', 'Land50234', 'NDVI_MEAN', '不透水面比例', '建筑密度', '容积率']
for col in base_cols:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# 2.1 先创建"POI总数"列（如果不存在）
poi_sub_cols = [col for col in df.columns if col.startswith('POI') and col != 'POI总数']
if 'POI总数' not in df.columns:
    if len(poi_sub_cols) > 0:
        df['POI总数'] = df[poi_sub_cols].sum(axis=1)
    else:
        raise ValueError("未找到POI子项列，无法计算POI总数！")

# 3. 计算"平均建筑高度"
df['平均建筑高度'] = df.apply(
    lambda row: row['容积率'] / row['建筑密度'] if row['建筑密度'] != 0 and not pd.isnull(row['建筑密度']) else 0,
    axis=1
)

# 4. 再保证所有分析用列为数值型
keep_names = ['Land01', 'Land02', 'Land03', 'Land50234', 'NDVI_MEAN', '不透水面比例', '建筑密度', '容积率', '平均建筑高度']
all_cols = keep_names + ['POI总数']
for col in all_cols:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# 5. 去除所有分析用特征和POI总数有缺失的行
df_valid = df.dropna(subset=keep_names + ['POI总数'])

X = df_valid[keep_names].values
y = df_valid['POI总数'].values

# 6. 判断"POI总数"是否能被保留的无冗余特征线性组合表示
reg = LinearRegression().fit(X, y)
y_pred = reg.predict(X)
r2 = reg.score(X, y)
mse = np.mean((y - y_pred) ** 2)
print(f"整体R2: {r2:.6f}, MSE: {mse:.6f}")
if r2 > 0.99999:
    print("POI总数可以被这些特征线性精确表示（冗余）")
else:
    print("POI总数不能被这些特征线性精确表示")

# 7. 枚举所有组合，找出能线性表示"POI总数"的特征组合
print("\n枚举所有组合，查找冗余关系：")
for n in range(1, len(keep_names)+1):
    for cols in combinations(keep_names, n):
        X_sub = df_valid[list(cols)].values
        reg = LinearRegression().fit(X_sub, y)
        r2 = reg.score(X_sub, y)
        if r2 > 0.99999:
            print(f"POI总数可以被{cols}线性精确表示")
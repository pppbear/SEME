import numpy as np
import torch
from kan.MultKAN import KAN
import pandas as pd
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error
import os
import pickle
import sys
sys.path.append('..')  # 添加父目录到系统路径
from cv_dataset import get_ten_fold_datasets
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
import logging

# 设置设备
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

def train_kan_model(X, y, input_dim, target_var):
    """训练KAN模型"""
    # 根据目标变量选择最佳参数
    if target_var == 'lst_day':
        params = {
            'width': [input_dim, 8,4,1],
            'grid': 8,
            'k': 3,
            'steps': 100,
            'lamb_l1': 0.01,
            'lamb_entropy': 0.01,
            'lr': 0.0001
        }
    elif target_var == 'lst_night':
        params = {
            'width': [input_dim, 8,4,1],
            'grid': 8,
            'k': 3,
            'steps': 100,
            'lamb_l1': 0.01,
            'lamb_entropy': 0.01,
            'lr': 0.0001
        }
    else:  # light
        params = {
            'width': [input_dim, 8,4,1],
            'grid': 8,
            'k': 3,
            'steps': 100,
            'lamb_l1': 0.01,
            'lamb_entropy': 0.01,
            'lr': 0.0001
        }
    
    # 创建训练集和测试集
    num_samples = X.shape[0]
    train_ratio = 0.8
    train_size = int(num_samples * train_ratio)
    
    # 随机打乱数据
    indices = np.random.permutation(num_samples)
    train_indices = indices[:train_size]
    test_indices = indices[train_size:]
    
    # 创建数据集字典，确保所有张量都在正确的设备上
    dataset = {
        'train_input': torch.tensor(X[train_indices], dtype=torch.float32, device=device),
        'train_label': torch.tensor(y[train_indices], dtype=torch.float32, device=device),
        'test_input': torch.tensor(X[test_indices], dtype=torch.float32, device=device),
        'test_label': torch.tensor(y[test_indices], dtype=torch.float32, device=device)
    }
    
    # 初始化模型
    model = KAN(
        width=params['width'],
        grid=params['grid'],
        k=params['k'],
        symbolic_enabled=True
    ).to(device)
    
    # 训练模型
    print(f"\n开始训练 {target_var} 模型...")
    print(f"训练集大小: {len(train_indices)}")
    print(f"测试集大小: {len(test_indices)}")
    
    # 使用KAN的fit方法
    results = model.fit(
        dataset=dataset,
        opt="LBFGS",
        steps=params['steps'],
        log=1,
        lamb=params.get('lamb', 0.001),
        lamb_l1=params.get('lamb_l1', 1.0),
        lamb_entropy=params.get('lamb_entropy', 2.0),
        update_grid=True,
        grid_update_num=params.get('grid_update_num', 10),
        loss_fn=None,
        lr=params['lr'],
        batch=params.get('batch_size', -1),
        metrics=None,
        save_fig=False,
        singularity_avoiding=True
    )
    
    # 评估模型
    model.eval()
    with torch.no_grad():
        X_tensor = torch.tensor(X, dtype=torch.float32, device=device)
        y_tensor = torch.tensor(y, dtype=torch.float32, device=device)
        y_pred = model(X_tensor).cpu().numpy()
        y_true = y_tensor.cpu().numpy()
    
    # 处理预测中的NaN值
    if np.isnan(y_pred).any():
        print("警告：预测结果中存在NaN值，将被替换为均值")
        y_mean = np.nanmean(y_true)
        y_pred = np.nan_to_num(y_pred, y_mean)
    
    # 计算评估指标
    r2 = r2_score(y_true, y_pred)
    rmse = np.sqrt(mean_squared_error(y_true, y_pred))
    mae = mean_absolute_error(y_true, y_pred)
    
    print(f"\n{target_var} 模型评估结果:")
    print(f"R²: {r2:.4f}")
    print(f"RMSE: {rmse:.4f}")
    print(f"MAE: {mae:.4f}")
    
    # 打印前10个样本的预测值和真实值对比
    print("\n前10个样本的预测值和真实值对比:")
    for i in range(min(10, len(y_true))):
        true_val = float(y_true[i]) if hasattr(y_true[i], '__len__') and not isinstance(y_true[i], str) and np.size(y_true[i]) == 1 else y_true[i]
        pred_val = float(y_pred[i]) if hasattr(y_pred[i], '__len__') and not isinstance(y_pred[i], str) and np.size(y_pred[i]) == 1 else y_pred[i]
        print(f"样本 {i+1}: 真实值 = {true_val:.4f}, 预测值 = {pred_val:.4f}")
    
    return model

def main():
    # 1. 读取数据
    data_file = 'shanghai_data.xlsx'
    df = pd.read_excel(data_file)

    # 先将基础列转为数值型
    base_cols = [
        'Land01', 'Land02', 'Land03', 'Land50234', 'NDVI_MEAN', '不透水面比例',
        '建筑密度', '容积率'
    ]
    for col in base_cols:
        df[col] = pd.to_numeric(df[col], errors='coerce')

    # 生成"平均建筑高度"
    df['平均建筑高度'] = df.apply(
        lambda row: row['容积率'] / row['建筑密度'] if row['建筑密度'] != 0 and not pd.isnull(row['建筑密度']) else 0,
        axis=1
    )

    # 生成"POI总数"
    poi_columns = [
        'POI餐饮服务_n', 'POI公司企业_n', 'POI购物服务_n', 'POI科教文化_n', 'POI商务住宅_n',
        'POI生活服务_n', 'POI体育休闲_n', 'POI医疗保健_n', 'POI政府机构团体_n', 'POI风景名胜_n'
    ]
    for col in poi_columns:
        df[col] = pd.to_numeric(df[col], errors='coerce')
    df['POI总数'] = df[poi_columns].sum(axis=1)

    # 只保留无缺失的样本
    keep_names = [
       'Land01', 'Land02', 'Land03', 'Land50234', 'NDVI_MEAN', '不透水面比例', '建筑密度', '容积率', '平均建筑高度'
    ]
    df = df.dropna(subset=keep_names)

    # 去除目标变量为缺失、0或'<空>'的行
    df = df[(df['lst_day_c'].notna()) & (df['lst_day_c'] != 0) & (df['lst_day_c'] != '<空>')]

    # 2. 自动去除线性冗余特征
    df_X = df[keep_names].copy()
    to_keep = []
    for i in range(df_X.shape[1]):
        if len(to_keep) == 0:
            to_keep.append(i)
        else:
            sub = df_X.iloc[:, to_keep + [i]]
            if np.linalg.matrix_rank(sub.values) > np.linalg.matrix_rank(df_X.iloc[:, to_keep].values):
                to_keep.append(i)
    keep_final = [keep_names[i] for i in to_keep]
    drop_final = [keep_names[i] for i in range(len(keep_names)) if i not in to_keep]
    print(f"保留的无冗余特征名: {keep_final}")
    print(f"去除的冗余特征名: {drop_final}")
    X = df_X[keep_final].values.astype(np.float32)
    y = df['lst_day_c'].values.astype(np.float32)

    # 3. 划分训练集和测试集
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
    # 后续将X_train, y_train, X_test, y_test用于KAN模型训练和评估

    # 检查特征与目标变量的相关性
    print("\n各特征与目标变量的皮尔逊相关系数：")
    corr_list = []
    for col in keep_final:
        corr = np.corrcoef(df[col], y)[0, 1]
        corr_list.append((col, corr))
    corr_list_sorted = sorted(corr_list, key=lambda x: abs(x[1]), reverse=True)
    for col, corr in corr_list_sorted:
        print(f"{col}: {corr:.4f}")

    # 训练模型
    model = train_kan_model(X, y, X.shape[1], 'lst_day_c')
    
    # 保存模型和特征
    model_path = 'models/lst_day_model.pth'
    torch.save({
        'model_state_dict': model.state_dict(),
        'feature_cols': keep_final,  # 保存保留的特征索引
        'model_params': {
            'width': model.width,
            'grid': model.grid,
            'k': model.k
        }
    }, model_path)
    with open('models/lst_day_features.txt', 'w', encoding='utf-8') as f:
        f.write('\n'.join(map(str, keep_final)))
    print(f"\n模型和特征已保存到 models/lst_day_*")

if __name__ == "__main__":
    main() 
import os
import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, Subset
from sklearn.model_selection import KFold
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
from sklearn.preprocessing import RobustScaler
import matplotlib.pyplot as plt
from kan.MultKAN import KAN
import gc
import logging
from kan import *
from cv_dataset import get_ten_fold_datasets
from utils import EarlyStopping, select_device
from itertools import product

# 设置中文显示
plt.rcParams['font.sans-serif'] = ['SimHei']
plt.rcParams['axes.unicode_minus'] = False

# 设置设备（GPU或CPU）
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
print(f"使用设备: {device}")

# 创建日志文件夹
log_dir = 'log'

# 如果文件夹不存在，则创建（exist_ok=True 避免文件夹已存在时抛出异常）
os.makedirs(log_dir, exist_ok=True)

# 设置日志文件路径
log_file = os.path.join(log_dir, 'cv_kan.log')

# 配置日志记录
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    encoding='utf-8'  # 添加UTF-8编码
)

# 同时配置控制台输出
console = logging.StreamHandler()
console.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console.setFormatter(formatter)
logging.getLogger('').addHandler(console)

def create_dataloader(city_dataset, fold_indices, batch_size=64, shuffle=True):
    """根据某一折的索引生成对应的 DataLoader"""
    if len(fold_indices) == 0:
        raise ValueError("fold_indices不能为空")
    
    subset = Subset(city_dataset, fold_indices)
    if len(subset) == 0:
        raise ValueError("子集为空")
    
    # 确保batch_size不超过数据集大小
    batch_size = min(batch_size, len(subset))
    
    dataloader = DataLoader(subset, batch_size=batch_size, shuffle=shuffle)
    return dataloader

def train_kan_model(model: KAN, train_dataloader, val_dataloader, params, device="cpu"):
    """使用KAN的fit方法训练模型"""
    logger = logging.getLogger(__name__)
    
    try:
        # 准备数据集
        train_inputs = []
        train_labels = []
        test_inputs = []
        test_labels = []
        
        for batch in train_dataloader:
            if len(batch) != 2:
                raise ValueError("训练数据格式错误")
            train_inputs.append(batch[0])
            train_labels.append(batch[1])
            
        for batch in val_dataloader:
            if len(batch) != 2:
                raise ValueError("验证数据格式错误")
            test_inputs.append(batch[0])
            test_labels.append(batch[1])
        
        if not train_inputs or not test_inputs:
            raise ValueError("数据集为空")
            
        train_dataset = {
            'train_input': torch.cat(train_inputs).to(device),
            'train_label': torch.cat(train_labels).to(device),
            'test_input': torch.cat(test_inputs).to(device),
            'test_label': torch.cat(test_labels).to(device)
        }
        
        # 使用KAN的fit方法
        results = model.fit(
            dataset=train_dataset,
            opt="LBFGS",
            steps=params['steps'],
            log=1,
            lamb=params.get('lamb', 0.001),
            lamb_l1=params.get('lamb_l1', 1.0),
            lamb_entropy=params.get('lamb_entropy', 2.0),
            update_grid=True,
            grid_update_num=params.get('grid_update_num', 10),
            loss_fn=None,
            lr=params['learning_rate'],
            batch=params.get('batch_size', -1),
            metrics=None,
            save_fig=False,
            singularity_avoiding=True
        )
         # 只记录最终的MSE
        return model, results
        
    except Exception as e:
        logger.error(f"训练过程中出错: {str(e)}")
        raise

def evaluate_kan_model(model: KAN, test_dataloader, device="cpu"):
    """评估KAN模型性能
    
    Args:
        model: KAN模型实例
        test_dataloader: 测试数据加载器
        device: 运行设备
        
    Returns:
        dict: 包含评估指标的字典
    """
    logger = logging.getLogger(__name__)
    
    try:
        # 准备测试数据
        test_inputs = []
        test_labels = []
        
        # 从DataLoader中收集所有数据
        for batch in test_dataloader:
            if len(batch) != 2:
                raise ValueError("测试数据格式错误")
            test_inputs.append(batch[0])
            test_labels.append(batch[1])
        
        if not test_inputs or not test_labels:
            raise ValueError("测试数据为空")
            
        # 合并所有批次的数据
        test_inputs = torch.cat(test_inputs).to(device)
        test_labels = torch.cat(test_labels).to(device)
        
        # 准备数据集字典
        dataset = {
            'test_input': test_inputs,
            'test_label': test_labels
        }
        
        # 评估模型
        model.eval()
        with torch.no_grad():
            y_pred = model(test_inputs)
            evaluation = model.evaluate(dataset)  # 修改这里，只传入dataset参数
        
        # 转换为numpy数组
        y_pred = y_pred.cpu().numpy()
        y_true = test_labels.cpu().numpy()
        
        # 计算评估指标
        mse = mean_squared_error(y_true, y_pred)
        r2 = r2_score(y_true, y_pred)
        
        # 检查评估指标的有效性
        if np.isnan(mse) or np.isinf(mse):
            raise ValueError("MSE计算结果无效")
        if np.isnan(r2) or np.isinf(r2):
            raise ValueError("R2计算结果无效")
            
        # 检查R2是否在合理范围内
        if r2 < -1 or r2 > 1:
            raise ValueError(f"R2值超出合理范围: {r2}")
            
        # 检查MSE是否为非负数
        if mse < 0:
            raise ValueError(f"MSE为负值: {mse}")
            
        # 检查预测值是否与真实值差异过大
        max_diff = np.max(np.abs(y_pred - y_true))
        if max_diff > 1e6:  # 设置一个合理的阈值
            raise ValueError(f"预测值与真实值差异过大: {max_diff}")
        
        # 计算模型复杂度指标
        complexity_metrics = {
            'n_edge': evaluation['n_edge'],
            'n_grid': evaluation['n_grid']
        }
        
        # 返回所有评估指标
        return {
            'mse': mse,
            'r2': r2,
            'test_loss': evaluation['test_loss'],
            'complexity': complexity_metrics,
            'predictions': y_pred
        }
        
    except Exception as e:
        logger.error(f"评估过程中出错: {str(e)}")
        raise

def generate_kan_params(learning_rates, hidden_dims, grid_sizes, k_values, input_size, n_hidden_layers_list):
    """生成KAN模型的超参数组合
    
    Args:
        learning_rates: 学习率列表
        hidden_dims: 隐藏层维度列表
        grid_sizes: 网格大小列表
        k_values: k值列表
        input_size: 输入特征维度
        n_hidden_layers_list: 隐藏层数列表
    """
    param_combinations = []
    
    for lr, hd, gs, k, n_layers in product(learning_rates, hidden_dims, grid_sizes, k_values, n_hidden_layers_list):
        # 根据隐藏层数生成不同的width配置
        if n_layers == 1:
            width = [input_size, hd, 1]  # 单隐藏层
        elif n_layers == 2:
            width = [input_size, hd, hd//2, 1]  # 双隐藏层，第二层神经元数减半

        
        params = {
            'learning_rate': lr,
            'hidden_dim': hd,
            'grid': gs,
            'k': k,
            'steps': 50,
            'batch_size': -1,
            'lamb': 0.001,
            'lamb_l1': 1.0,
            'lamb_entropy': 2.0,
            'grid_update_num': 10,
            'width': width,  # 添加width参数
            'n_hidden_layers': n_layers  # 添加隐藏层数信息
        }
        param_combinations.append(params)
        
    return param_combinations

def nested_cross_validation_kan(city_dataset, fold_indices, param_combinations, device="cpu"):
    """执行KAN模型的嵌套交叉验证"""
    logger = logging.getLogger(__name__)
    n_folds = 10
    outer_metrics = {
        'MSE': [], 'R2': [],
        'reg_loss': [], 'grid_quality': []
    }

    best_model_info = {
        'model': None,
        'params': None,
        'fold': None,
        'metrics': None,
        'score': float('inf')
    }

    # 记录数据集信息
    logger.info(f"数据集信息:")
    logger.info(f"- 特征维度: {city_dataset.features.shape[1]}")
    logger.info(f"- 样本数量: {len(city_dataset)}")
    logger.info(f"- 设备: {device}")
    
    # 记录参数组合信息
    logger.info(f"参数组合信息:")
    logger.info(f"- 总参数组合数: {len(param_combinations)}")
    logger.info(f"- 参数范围:")
    for i, params in enumerate(param_combinations[:3]):  # 只显示前3个组合作为示例
        logger.info(f"  组合 {i+1}: {params}")
    if len(param_combinations) > 3:
        logger.info(f"  ... 等 {len(param_combinations)} 个组合")

    logger.info(f"开始交叉验证...")

    for outer_test_fold in range(n_folds):
        logger.info(f"{'='*50}")
        logger.info(f"外层循环 - 测试折 {outer_test_fold + 1}/{n_folds}")
        logger.info(f"{'='*50}")
        
        outer_train_folds = [i for i in range(n_folds) if i != outer_test_fold]
        best_params = None
        best_inner_score = float('inf')

        # 内层交叉验证
        for params_idx, params in enumerate(param_combinations):
            logger.info(f"--- 参数组合 {params_idx + 1}/{len(param_combinations)} ---")
            logger.info(f"参数:")
            logger.info(f"- 隐藏层数: {params['n_hidden_layers']}")
            logger.info(f"- 隐藏层维度: {params['hidden_dim']}")
            logger.info(f"- 网格大小: {params['grid']}")
            logger.info(f"- k值: {params['k']}")
            logger.info(f"- 网络结构: {params['width']}")
            
            inner_losses = []
            inner_metrics = []
            skip_params = False  # 添加标志来标记是否跳过当前参数组合
            
            for inner_valid_fold in outer_train_folds:
                if skip_params:  # 如果标记为跳过，直接进入下一个参数组合
                    break
                    
                logger.info(f"内层循环 - 验证折 {inner_valid_fold + 1}/{n_folds}")
                
                inner_train_folds = [i for i in outer_train_folds if i != inner_valid_fold]
                
                # 获取训练和验证数据
                train_indices = np.concatenate([fold_indices[i] for i in inner_train_folds])
                valid_indices = fold_indices[inner_valid_fold]
                train_loader = create_dataloader(city_dataset, train_indices)
                valid_loader = create_dataloader(city_dataset, valid_indices)

                # 初始化模型
                input_size = city_dataset.features.shape[1]
                model = KAN(
                    width=params['width'],  # 使用参数中的width配置
                    grid=params['grid'],
                    k=params['k'],
                    device=device
                ).to(device)

                try:
                    # 训练模型
                    model, train_results = train_kan_model(model, train_loader, valid_loader, params, device)
                    
                    # 评估模型
                    metrics = evaluate_kan_model(model, valid_loader, device)
                    
                    # 检查预测值是否包含NaN或Inf
                    if np.isnan(metrics['mse']) or np.isinf(metrics['mse']):
                        logger.warning(f"参数组合 {params} 产生无效结果，跳过此组合")
                        skip_params = True
                        break
                        
                    # 检查R2是否在合理范围内
                    if metrics['r2'] < -1 or metrics['r2'] > 1:
                        logger.warning(f"参数组合 {params} 产生无效的R2值: {metrics['r2']}，跳过此组合")
                        skip_params = True
                        break
                        
                    # 检查MSE是否为非负数
                    if metrics['mse'] < 0:
                        logger.warning(f"参数组合 {params} 产生负的MSE值: {metrics['mse']}，跳过此组合")
                        skip_params = True
                        break
                        
                    metrics['reg_loss'] = train_results['reg'][-1] if 'reg' in train_results else 0.0
                    metrics['grid_quality'] = train_results.get('grid_quality', 0.0)
                    
                    inner_losses.append(metrics['mse'])
                    inner_metrics.append(metrics)
                    
                except Exception as e:
                    logger.error(f"参数组合 {params} 在验证折 {inner_valid_fold + 1} 上训练失败: {str(e)}")
                    skip_params = True
                    break

            if skip_params:  # 如果标记为跳过，继续下一个参数组合
                continue
                
            if not inner_losses:  # 如果所有参数组合都失败
                logger.error(f"所有参数组合在验证折 {inner_valid_fold} 上都失败了")
                continue
                
            avg_inner_loss = np.mean(inner_losses)
            std_inner_loss = np.std(inner_losses)
            logger.info(f"当前参数组合的平均MSE: {avg_inner_loss:.4f} ± {std_inner_loss:.4f}")

            if avg_inner_loss < best_inner_score:
                best_inner_score = avg_inner_loss
                best_params = params
                logger.info(f"发现更好的参数组合！新的最佳MSE: {best_inner_score:.4f}")

        if best_params is None:
            logger.error(f"外层折 {outer_test_fold + 1} 没有找到有效的参数组合")
            continue
            
        logger.info(f"\n当前外层折的最佳参数: {best_params}")
        
        # 外层测试
        outer_train_indices = np.concatenate([fold_indices[i] for i in outer_train_folds])
        outer_test_indices = fold_indices[outer_test_fold]
        
        logger.info(f"\n外层测试:")
        
        train_loader = create_dataloader(city_dataset, outer_train_indices)
        test_loader = create_dataloader(city_dataset, outer_test_indices)

        # 训练最终模型
        model = KAN(
            width=best_params['width'],  # 使用最佳参数中的width配置
            grid=best_params['grid'],
            k=best_params['k'],
            device=device
        ).to(device)
        
        try:
            logger.info("训练最终模型...")
            model, final_results = train_kan_model(model, train_loader, test_loader, best_params, device)
            
            # 评估最终模型
            logger.info("评估最终模型...")
            metrics = evaluate_kan_model(model, test_loader, device)
            metrics['reg_loss'] = final_results['reg'][-1] if 'reg' in final_results else 0.0
            metrics['grid_quality'] = final_results.get('grid_quality', 0.0)
            
            logger.info(f"最终模型评估结果:")
            for metric_name, metric_value in metrics.items():
                if isinstance(metric_value, dict):
                    logger.info(f"- {metric_name}: {metric_value}")
                else:
                    logger.info(f"- {metric_name}: {metric_value:.4f}")
            
            # 更新指标
            for metric in outer_metrics:
                outer_metrics[metric].append(metrics[metric])
            
            # 检查是否是最佳模型
            if metrics['mse'] < best_model_info['score']:
                best_model_info.update({
                    'model': model,
                    'params': best_params,
                    'fold': outer_test_fold,
                    'metrics': metrics,
                    'score': metrics['mse']
                })
                
                logger.info(f"\n发现新的最佳模型！")
                logger.info(f"- 来自第 {outer_test_fold + 1} 折")
                logger.info(f"- MSE: {metrics['mse']:.4f}")
                
                # 保存最佳模型和结果
                try:
                    os.makedirs('results/kan', exist_ok=True)
                    # 保存模型状态
                    torch.save({
                        'model_state_dict': model.state_dict(),
                        'params': best_params,
                        'fold': outer_test_fold,
                        'metrics': metrics
                    }, 'results/kan/best_model.pt')
                    
                    # 保存评估结果
                    with open('results/kan/best_model_results.txt', 'w', encoding='utf-8') as f:
                        f.write(f"最佳模型信息:\n")
                        f.write(f"来自第 {outer_test_fold + 1} 折\n")
                        f.write(f"参数: {best_params}\n\n")
                        f.write("评估指标:\n")
                        for metric, value in metrics.items():
                            f.write(f"{metric}: {value}\n")
                        f.write("\n训练历史:\n")
                        for key, values in final_results.items():
                            f.write(f"{key}: {values[-1]}\n")
                            
                    logger.info("最佳模型已保存")
                except Exception as e:
                    logger.error(f"保存最佳模型时出错: {str(e)}")
            # 显式释放模型和清理显存，防止显存泄漏
            del model
            gc.collect()
            if device.type == 'cuda':
                torch.cuda.empty_cache()
            except Exception as e:
            logger.error(f"外层折 {outer_test_fold + 1} 的最终模型训练失败: {str(e)}")
            continue
    
    # 计算并打印最终结果
    if not outer_metrics['MSE']:  # 检查是否有有效的结果
        logger.error("没有成功完成任何外层折的评估")
        return None
        
    logger.info("\n===== 交叉验证最终结果 =====")
    for metric in outer_metrics:
        mean_val = np.mean(outer_metrics[metric])
        std_val = np.std(outer_metrics[metric])
        logger.info(f"{metric}: {mean_val:.4f} ± {std_val:.4f}")
    
    # 打印最佳模型信息
    if best_model_info['model'] is not None:
        logger.info("\n===== 最佳模型信息 =====")
        logger.info(f"来自第 {best_model_info['fold'] + 1} 折")
        logger.info(f"参数: {best_model_info['params']}")
        logger.info(f"评估指标: {best_model_info['metrics']}")
    else:
        logger.error("没有找到有效的最佳模型")
    
    return outer_metrics

def main():
    # 设置CUDA优化
    if torch.cuda.is_available():
        torch.backends.cudnn.benchmark = True
        current_device = torch.cuda.current_device()
        print(f"当前GPU设备: {torch.cuda.get_device_name(current_device)}")
        print(f"GPU设备能力: {torch.cuda.get_device_capability(current_device)}")
        print(f"GPU设备总数: {torch.cuda.device_count()}")
        print(f"GPU显存总量: {torch.cuda.get_device_properties(current_device).total_memory / 1024**3:.2f} GB")
        print(f"当前已分配显存: {torch.cuda.memory_allocated(current_device) / 1024**3:.2f} GB")
        print(f"当前显存预留: {torch.cuda.memory_reserved(current_device) / 1024**3:.2f} GB")
    else:
        print("警告: 未检测到可用的GPU，将使用CPU运行，这可能会导致训练速度显著变慢！")
    
    # 创建结果目录
    os.makedirs('results/kan', exist_ok=True)
    
    # 加载数据
    data_file = 'shanghai_data.xlsx'
    target_vars = ['lst_day', 'lst_night', 'light']  # 修改目标变量名称
    for target_var in target_vars:
        logging.info(f"\n{'='*50}")
        logging.info(f"处理目标变量: {target_var}")
        logging.info(f"{'='*50}")
        
        # 使用cv_dataset.py中的方法获取数据集
        city_dataset, fold_indices, feature_names = get_ten_fold_datasets(data_file, target_var)
        X = city_dataset.features.cpu().numpy()
        y = city_dataset.labels.cpu().numpy()

        # ====== 十折划分后冗余特征处理（保留原始特征名）======
        import pandas as pd
        df_X = pd.DataFrame(X, columns=feature_names)
        # 如果有POI总数，只保留POI总数和非POI相关特征
        poi_sub_cols = [col for col in feature_names if col.startswith('POI') and col != 'POI总数']
        if 'POI总数' in feature_names:
            keep_base = [col for col in feature_names if not col.startswith('POI') or col == 'POI总数']
            logging.info(f"检测到'POI总数'，将只保留'POI总数'和非POI相关特征: {keep_base}")
            df_X = df_X[keep_base]
            feature_names = keep_base
        else:
            logging.info(f"未检测到'POI总数'，所有POI子项参与递归筛选。")
        # 递归筛选线性无关特征
        to_keep = []
        for i in range(df_X.shape[1]):
            if len(to_keep) == 0:
                to_keep.append(i)
            else:
                sub = df_X.iloc[:, to_keep + [i]]
                if np.linalg.matrix_rank(sub.values) > np.linalg.matrix_rank(df_X.iloc[:, to_keep].values):
                    to_keep.append(i)
        keep_names = [feature_names[i] for i in to_keep]
        drop_names = [feature_names[i] for i in range(len(feature_names)) if i not in to_keep]
        logging.info(f"保留的无冗余特征名: {keep_names}")
        logging.info(f"去除的冗余特征名: {drop_names}")
        city_dataset.features = torch.tensor(df_X.iloc[:, to_keep].values, dtype=torch.float32)
        # ====== 冗余特征处理结束 ======

        # 用实际特征数生成参数组合
        input_size = len(keep_names)
             # 定义参数网格
        learning_rates = [0.0001]
        hidden_dims = [ 8, 64, 256, 1024]
        grid_sizes = [ 4 ,6, 8, 10]
        k_values = [2, 3,]
        n_hidden_layers_list = [1, 2]  # 定义隐藏层数列表

        param_combinations = generate_kan_params(
            learning_rates=learning_rates,
            hidden_dims=hidden_dims,
            grid_sizes=grid_sizes,
            k_values=k_values,
            input_size=input_size,
            n_hidden_layers_list=n_hidden_layers_list
        )
        
        # 执行交叉验证
        results = nested_cross_validation_kan(city_dataset, fold_indices, param_combinations, device)
        
        # 保存最终结果
        with open('results/kan/cross_validation_results.txt', 'w', encoding='utf-8') as f:
            f.write("===== KAN模型交叉验证结果 =====\n\n")
            for metric in results:
                mean_val = np.mean(results[metric])
                std_val = np.std(results[metric])
                f.write(f"{metric}: {mean_val:.4f} ± {std_val:.4f}\n")

if __name__ == "__main__":
    main() 
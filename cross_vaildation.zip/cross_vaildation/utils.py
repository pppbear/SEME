import torch

# 训练设备(使用GPU)
def select_device(gpu_id = None):
    if gpu_id is None:
        print("select device CPU")
        return torch.device("cpu")
    if torch.cuda.is_available():
        print("select device GPU")
        return torch.device("cuda:" + str(gpu_id))
    print("have to select device CPU")
    return torch.device("cpu")

# 采用早停策略
class EarlyStopping:
    def __init__(self, patience=5, min_delta=0):
        """
        Args:
            patience (int): 没有改善的epoch数量,在此之后会停止训练。
            min_delta (float): 判断是否有改善的最小变化值。
        """
        self.patience = patience
        self.min_delta = min_delta
        self.best_loss = None
        self.counter = 0
        self.early_stop = False

    def __call__(self, val_loss):
        if self.best_loss is None:
            self.best_loss = val_loss
        elif val_loss < self.best_loss - self.min_delta:
            self.best_loss = val_loss
            self.counter = 0  # 重置计数
        else:
            self.counter += 1
            if self.counter >= self.patience:
                self.early_stop = True
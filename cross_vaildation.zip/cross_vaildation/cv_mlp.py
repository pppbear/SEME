import torch
import torch.optim as optim
import torch.nn as nn
import numpy as np
import logging
import os
from model import MLP
from cv_dataset import get_ten_fold_datasets
from utils import EarlyStopping, select_device
from itertools import product
from torch.utils.data import DataLoader, Subset
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from scipy.stats import pearsonr, spearmanr

# 创建日志文件夹
log_dir = 'log'

# 如果文件夹不存在，则创建（exist_ok=True 避免文件夹已存在时抛出异常）
os.makedirs(log_dir, exist_ok=True)

# 设置日志文件路径
log_file = os.path.join(log_dir, 'cv_mlp.log')

# 配置日志记录
logging.basicConfig(filename=log_file, level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

def create_dataloader(city_dataset, fold_indices, batch_size=64, shuffle=True):
    """
    根据某一折的索引生成对应的 DataLoader。
    
    Args:
        city_dataset (Dataset): 原始的城市数据集。
        fold_indices (list): 当前折的数据索引。
        batch_size (int): 每批次的大小。
        shuffle (bool): 是否对数据进行打乱。

    Returns:
        DataLoader: 对应折的 DataLoader。
    """
    subset = Subset(city_dataset, fold_indices)  # 根据索引选出该折的数据子集
    dataloader = DataLoader(subset, batch_size=batch_size, shuffle=shuffle)
    return dataloader

# 验证过程的封装函数
def validate_mlp_model(model, val_dataloader, device="cpu"):
    model.eval()
    val_loss = 0.0
    criterion = nn.MSELoss()  # 使用均方误差作为验证损失

    with torch.no_grad():
        for batch_features, batch_labels in val_dataloader:
            batch_features, batch_labels = batch_features.to(device), batch_labels.to(device)
            outputs = model(batch_features)
            loss = criterion(outputs, batch_labels.view(-1, 1))
            val_loss += loss.item()

    # 返回验证集的平均损失
    average_val_loss = val_loss / len(val_dataloader)
    return average_val_loss

# 训练过程的封装函数
def train_and_validate_mlp_model(train_dataloader, val_dataloader, model, criterion, patience=5, learning_rate=0.001, max_epochs=5000, device="cpu"):
    early_stopping = EarlyStopping(patience=patience)
    optimizer = optim.Adam(model.parameters(), lr=learning_rate, weight_decay=1e-5)
    last_train_loss = None  # 用于保存训练停止前的最后一个损失
    last_val_loss = None

     # 开始训练循环
    for epoch in range(max_epochs):
        model.train()
        running_loss = 0.0
        for batch_features, batch_labels in train_dataloader:
            batch_features, batch_labels = batch_features.to(device), batch_labels.to(device)
            
            optimizer.zero_grad()
            outputs = model(batch_features)
            loss = criterion(outputs, batch_labels.view(-1, 1))
            loss.backward()
            optimizer.step()
            
            running_loss += loss.item()
        
        # 记录每个epoch的平均损失
        average_train_loss = running_loss / len(train_dataloader)
        last_train_loss = average_train_loss  # 更新为当前 epoch 的平均损失

        average_val_loss = validate_mlp_model(model, val_dataloader, device)
        last_val_loss = average_val_loss

        # 打印每个 epoch 的训练和验证损失
        # print(f"Epoch {epoch + 1}: Train Loss = {average_train_loss:.4f}, Val Loss = {average_val_loss:.4f}")

        # 早停机制判断
        early_stopping(average_val_loss)
        if early_stopping.early_stop:
            logging.info(f"Early stopping at epoch {epoch + 1}")
            break

    return last_train_loss, last_val_loss # 返回最后一个有效训练和验证损失


# 测试过程的封装函数
def evaluate_mlp_model(model, test_dataloader, device="cpu"):
    """
    测试模型并计算各项性能指标。

    Args:
        model: 要评估的模型。
        test_dataloader: 测试集的 DataLoader。
        device: 设备 (CPU 或 GPU)。
        value_threshold (float): 用于计算准确率的预测值与真实值的差异阈值。

    Returns:
        dict: 包含所有性能指标的字典。
    """
    model.eval()  # 设定模型为评估模式
    
    test_true_values = []
    test_predicted_values = []

    with torch.no_grad():  # 在评估模型时，不需要计算梯度
        for batch_features, batch_labels in test_dataloader:
            batch_features = batch_features.to(device)
            batch_labels = batch_labels.to(device)

            # 前向传播
            outputs = model(batch_features)

            # 计算准确率
            predicted = outputs.squeeze()  # 去掉多余的维度

            # 保存真实值和预测值，将其展平为一维数组
            test_true_values.extend(batch_labels.view(-1).tolist())
            test_predicted_values.extend(predicted.view(-1).tolist())

    # 计算性能指标
    mse = mean_squared_error(test_true_values, test_predicted_values)
    rmse = np.sqrt(mse)
    mae = mean_absolute_error(test_true_values, test_predicted_values)
    r2 = r2_score(test_true_values, test_predicted_values)

    # 计算 95% 置信区间
    ci95 = 1.96 * np.std(np.array(test_predicted_values) - np.array(test_true_values)) / np.sqrt(len(test_true_values))

    # 计算 Pearson 和 Spearman 指数
    pearson_corr, _ = pearsonr(test_true_values, test_predicted_values)
    spearman_corr, _ = spearmanr(test_true_values, test_predicted_values)

    # 计算不同绝对误差范围的百分比
    within_2 = np.mean(np.abs(np.array(test_true_values) - np.array(test_predicted_values)) < 2) * 100
    within_5 = np.mean(np.abs(np.array(test_true_values) - np.array(test_predicted_values)) < 5) * 100
    within_10 = np.mean(np.abs(np.array(test_true_values) - np.array(test_predicted_values)) < 10) * 100

    # 返回所有性能指标
    metrics = {
        'MSE': mse,
        'RMSE': rmse,
        'MAE': mae,
        'R2': r2,
        'CI95': ci95,
        'Pearson': pearson_corr,
        'Spearman': spearman_corr,
        'within_2': within_2,
        'within_5': within_5,
        'within_10': within_10
    }

    return metrics

def generate_mlp_params(learning_rates, patiences, hidden_layers_configs, loss_functions):
    """
    生成 MLP 超参数组合。
    
    参数:
    - learning_rates: 学习率列表。
    - patiences: 早停的 patience 参数列表。
    - hidden_layers_configs: 隐藏层配置列表，每项是一个包含层数、每层神经元数量和激活函数的列表。
    - loss_functions: 损失函数列表。
    
    返回:
    - param_combinations: 包含超参数组合的字典列表。
    """
    param_combinations = [
        {
            'learning_rate': lr,
            'patience': p,
            'hidden_layers': hl,
            'loss_function': lf
        }
        for lr, p, hl, lf in product(learning_rates, patiences, hidden_layers_configs, loss_functions)
    ]
    return param_combinations


def nested_cross_validation_mlp(city_dataset, fold_indices, param_combinations, device="cpu"):
    n_folds = 10
    outer_metrics = {
        'MSE': [], 'RMSE': [], 'MAE': [], 'R2': [],
        'CI95': [], 'Pearson': [], 'Spearman': [],
        'within_2': [], 'within_5': [], 'within_10': []
    }

    for outer_test_fold in range(n_folds):
        logging.info(f"Outer loop, test fold is {outer_test_fold}")
        outer_train_folds = [i for i in range(n_folds) if i != outer_test_fold]
        best_params = None
        best_inner_score = float('inf')

        # 内层交叉验证，用于超参数选择
        for params in param_combinations:
            inner_losses = []
            for inner_valid_fold in outer_train_folds:
                inner_train_folds = [i for i in outer_train_folds if i != inner_valid_fold]

                # 获取训练和验证数据
                train_indices = np.concatenate([fold_indices[i] for i in inner_train_folds])
                valid_indices = fold_indices[inner_valid_fold]
                train_loader = create_dataloader(city_dataset, train_indices)
                valid_loader = create_dataloader(city_dataset, valid_indices)

                # 定义模型和损失函数
                input_size = city_dataset.features.shape[1]
                output_size = 1
                model = MLP(input_size, params['hidden_layers'], output_size).to(device)
                criterion = params['loss_function']

                # 训练和验证模型
                train_loss, val_loss= train_and_validate_mlp_model(train_loader, valid_loader, model, criterion, patience=params['patience'],
                                               learning_rate=params['learning_rate'], device=device)
                inner_losses.append(val_loss)

            avg_inner_loss = np.mean(inner_losses)
            logging.info(f"The mse of this group of params is {avg_inner_loss}.")

            if avg_inner_loss < best_inner_score:
                best_inner_score = avg_inner_loss
                best_params = params

        logging.info(f"Best hyperparameters found for fold {outer_test_fold}: {best_params}")
        
        # 外层测试
        outer_train_indices = np.concatenate([fold_indices[i] for i in outer_train_folds])
        outer_test_indices = fold_indices[outer_test_fold]
        train_loader = create_dataloader(city_dataset, outer_train_indices)
        test_loader = create_dataloader(city_dataset, outer_test_indices)

        model = MLP(input_size, best_params['hidden_layers'], output_size).to(device)
        criterion = best_params['loss_function']
        train_and_validate_mlp_model(train_loader, test_loader, model, criterion, patience=best_params['patience'],
                        learning_rate=best_params['learning_rate'], device=device)

        # 测试模型并计算性能指标
        metrics = evaluate_mlp_model(model, test_loader, device=device)
        
        # 将结果添加到outer_metrics
        for key, value in metrics.items():
            outer_metrics[key].append(value)

    # 计算平均性能指标
    avg_metrics = {k: np.mean(v) for k, v in outer_metrics.items()}
    logging.info("\nFinal Averaged Metrics:")
    for metric, value in avg_metrics.items():
        logging.info(f"{metric}: {value:.3f}")

    return outer_metrics

# 调用生成十折交叉验证的数据
data_file = "shanghai_data.xlsx"
device = select_device(0)
city_dataset, fold_indices = get_ten_fold_datasets(data_file, "light")

# 配置超参数
learning_rates = [0.001, 0.005, 0.01]
patiences = [5, 10, 20]
hidden_layers_configs = [
    [(1024, 'relu')],
    [(2048, 'relu')],
    [(4096, 'relu')],
    [(8192, 'relu')],
    [(1024, 'relu'), (1024, 'relu')],
    [(1024, 'relu'), (2048, 'tanh'), (1024, 'relu')]
]
loss_functions = [nn.MSELoss(), nn.L1Loss(), nn.SmoothL1Loss()]

# 生成参数组合
param_combinations = generate_mlp_params(learning_rates, patiences, hidden_layers_configs, loss_functions)

# 调用嵌套交叉验证
nested_cross_validation_mlp(city_dataset, fold_indices, param_combinations, device=device)
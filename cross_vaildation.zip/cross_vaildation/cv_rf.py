from itertools import product
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from scipy.stats import pearsonr, spearmanr
from cv_dataset import get_ten_fold_datasets
import numpy as np
import torch
import logging
import os

# 创建日志文件夹
log_dir = 'cv_lst_day_log'

# 如果文件夹不存在，则创建（exist_ok=True 避免文件夹已存在时抛出异常）
os.makedirs(log_dir, exist_ok=True)

# 设置日志文件路径
log_file = os.path.join(log_dir, 'cv_rf.log')

# 配置日志记录
logging.basicConfig(filename=log_file, level=logging.INFO, 
                    format='%(asctime)s - %(levelname)s - %(message)s')

# 运算设备
def select_device(gpu_id = None):
    if gpu_id is None:
        logging.info("select device CPU")
        return torch.device("cpu")
    if torch.cuda.is_available():
        logging.info("select device GPU")
        return torch.device("cuda:" + str(gpu_id))
    logging.info("have to select device CPU")
    return torch.device("cpu")
device = select_device(0)

# 调用生成十折交叉验证的数据
data_file = "shanghai_data.xlsx"
city_dataset, fold_indices = get_ten_fold_datasets(data_file, "uhi_night")

# 定义生成超参数组合的函数
def generate_rf_params(n_estimators_list, max_depth_list):
    """
    生成随机森林超参数组合的列表。
    
    参数:
    - n_estimators_list: 包含所有要尝试的 `n_estimators` 值的列表。
    - max_depth_list: 包含所有要尝试的 `max_depth` 值的列表。
    
    返回:
    - rf_params: 包含所有 (n_estimators, max_depth) 组合的字典列表。
    """
    rf_params = [{'n_estimators': n, 'max_depth': d} for n, d in product(n_estimators_list, max_depth_list)]
    return rf_params

# 嵌套交叉验证函数
def nested_cross_validation(city_dataset, fold_indices, random_seed=42):
    n_folds = 10
    outer_metrics = {
        'MSE': [], 'RMSE': [], 'MAE': [], 'R2': [],
        'CI95': [], 'Pearson': [], 'Spearman': [],
        'within_2': [], 'within_5': [], 'within_10': []
    }

    # 超参数选取范围
    n_estimators_list = [50, 100, 150]
    max_depth_list = [None, 10, 20]
    rf_params = generate_rf_params(n_estimators_list, max_depth_list)
    
    for outer_test_fold in range(n_folds):
        logging.info(f"outer turn strat, test fold is fold {outer_test_fold}, others for training.")
        outer_train_folds = [i for i in range(n_folds) if i != outer_test_fold]
        best_params = None
        best_inner_score = float('inf')

        # 内循环：遍历超参数组合
        for params in rf_params:
            logging.info(f"Evaluating hyperparameters: n_estimators={params['n_estimators']}, max_depth={params['max_depth']}")
            inner_losses = []
            
            # 内层交叉验证
            for inner_valid_fold in outer_train_folds:
                logging.info('inner turn start')
                inner_train_folds = [i for i in outer_train_folds if i != inner_valid_fold]
                
                # 获取内层训练集和验证集数据
                inner_train_indices = np.concatenate([fold_indices[i] for i in inner_train_folds])
                inner_valid_indices = fold_indices[inner_valid_fold]
                train_features = city_dataset.features[inner_train_indices].numpy()
                train_labels = city_dataset.labels[inner_train_indices].numpy().flatten()
                valid_features = city_dataset.features[inner_valid_indices].numpy()
                valid_labels = city_dataset.labels[inner_valid_indices].numpy().flatten()

                # 创建并训练模型
                rf_model = RandomForestRegressor(**params, random_state=random_seed)
                rf_model.fit(train_features, train_labels)
                valid_preds = rf_model.predict(valid_features)
                valid_mse = mean_squared_error(valid_labels, valid_preds)
                inner_losses.append(valid_mse)
                
            # 计算该参数组合的平均验证误差
            avg_inner_loss = np.mean(inner_losses)
            
            # 检查是否是最佳参数组合
            if avg_inner_loss < best_inner_score:
                best_inner_score = avg_inner_loss
                best_params = params

        logging.info(f"Best hyperparameters found for fold {outer_test_fold}: n_estimators={best_params['n_estimators']}, max_depth={best_params['max_depth']}")
        # 外层循环：测试最佳超参数组合
        outer_train_indices = np.concatenate([fold_indices[i] for i in outer_train_folds])
        outer_test_indices = fold_indices[outer_test_fold]
        train_features = city_dataset.features[outer_train_indices].numpy()
        train_labels = city_dataset.labels[outer_train_indices].numpy().flatten()
        test_features = city_dataset.features[outer_test_indices].numpy()
        test_labels = city_dataset.labels[outer_test_indices].numpy().flatten()

        # 训练RandomForest模型
        rf_model = RandomForestRegressor(**best_params, random_state=random_seed)
        rf_model.fit(train_features, train_labels)
        test_preds = rf_model.predict(test_features)

        # 计算性能指标
        mse = mean_squared_error(test_labels, test_preds)
        rmse = mean_squared_error(test_labels, test_preds, squared=False)
        mae = mean_absolute_error(test_labels, test_preds)
        r2 = r2_score(test_labels, test_preds)
        pearson_corr, _ = pearsonr(test_labels, test_preds)
        spearman_corr, _ = spearmanr(test_labels, test_preds)
        ci95 = 1.96 * np.std(test_preds - test_labels) / np.sqrt(len(test_labels))
        within_2 = np.mean(np.abs(test_labels - test_preds) < 2) * 100
        within_5 = np.mean(np.abs(test_labels - test_preds) < 5) * 100
        within_10 = np.mean(np.abs(test_labels - test_preds) < 10) * 100

        # 存储结果
        outer_metrics['MSE'].append(mse)
        outer_metrics['RMSE'].append(rmse)
        outer_metrics['MAE'].append(mae)
        outer_metrics['R2'].append(r2)
        outer_metrics['CI95'].append(ci95)
        outer_metrics['Pearson'].append(pearson_corr)
        outer_metrics['Spearman'].append(spearman_corr)
        outer_metrics['within_2'].append(within_2)
        outer_metrics['within_5'].append(within_5)
        outer_metrics['within_10'].append(within_10)

        logging.info(f"RandomForest - Outer Fold {outer_test_fold + 1}: MSE={mse:.3f}, RMSE={rmse:.3f}, MAE={mae:.3f}, R2={r2:.3f}")
        logging.info(f"Pearson={pearson_corr:.3f}, Spearman={spearman_corr:.3f}, CI95={ci95:.3f}")
        logging.info(f"Within ±2: {within_2:.2f}%, ±5: {within_5:.2f}%, ±10: {within_10:.2f}%\n")

    # 计算平均性能
    avg_metrics = {k: np.mean(v) for k, v in outer_metrics.items()}
    logging.info("\nFinal Averaged Metrics:")
    for metric, value in avg_metrics.items():
        logging.info(f"{metric}: {value:.3f}")

    return outer_metrics

nested_cross_validation(city_dataset, fold_indices)
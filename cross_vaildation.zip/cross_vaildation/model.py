import torch
import torch.nn as nn
import math

class MLP(nn.Module):
    def __init__(self, input_size, hidden_layers, output_size):
        """
        参数:
        - input_size (int): 输入特征的大小。
        - hidden_layers (list of tuples): 每个隐藏层的配置。列表中的每个元组包含 (hidden_size, activation)，
                                           其中 hidden_size 是该层的神经元个数，activation 是激活函数的类型（'relu'、'sigmoid'、'tanh'）。
        - output_size (int): 输出层的神经元个数。
        """
        super(MLP, self).__init__()
        
        # 定义输入层前的归一化层
        self.batch_norm = nn.BatchNorm1d(input_size)
        
        # 创建输入层
        layers = []
        layers.append(self._create_layer(input_size, hidden_layers[0][0], hidden_layers[0][1]))
        
        # 创建隐藏层
        for i in range(1, len(hidden_layers)):
            in_features = hidden_layers[i - 1][0]
            out_features = hidden_layers[i][0]
            activation = hidden_layers[i][1]
            layers.append(self._create_layer(in_features, out_features, activation))
        
        # 创建输出层
        self.hidden_layers = nn.Sequential(*layers)
        self.output_layer = nn.Linear(hidden_layers[-1][0], output_size)
        
    def _create_layer(self, in_features, out_features, activation):
        """
        创建包含全连接层和激活函数的单层模块。
        
        参数:
        - in_features (int): 输入特征的大小。
        - out_features (int): 输出特征的大小。
        - activation (str): 激活函数的类型（'relu'、'sigmoid'、'tanh'）。
        
        返回:
        - nn.Sequential: 包含全连接层和激活函数的模块。
        """
        layer = [nn.Linear(in_features, out_features)]
        
        if activation == 'relu':
            layer.append(nn.ReLU())
        elif activation == 'sigmoid':
            layer.append(nn.Sigmoid())
        elif activation == 'tanh':
            layer.append(nn.Tanh())
        
        return nn.Sequential(*layer)
    
    def forward(self, x):
        x = self.batch_norm(x)
        x = self.hidden_layers(x)
        x = self.output_layer(x)
        return x

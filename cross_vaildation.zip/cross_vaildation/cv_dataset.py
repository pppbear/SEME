import pandas as pd
import numpy as np
import torch
from torch.utils.data import Dataset
from sklearn.model_selection import StratifiedKFold

# 加载和构建预测夜间灯光强度数据集的预处理函数
def excel_predict_light_filter(file_name):
    df = pd.read_excel(file_name)
    # sidewalk_MEAN building_MEAN vegetation_MEAN sky_MEAN(街景数据量不足) lst_day_c lst_night_c uhi_day_c uhi_night_c(暂不作为预测指标)
    # 根据相关性分析 公园绿地用地占比和铁路长度与夜间灯光强度相关性极低 不作为输入
    columns_to_drop = ['sidewalk_MEAN', 'building_MEAN', 'vegetation_MEAN', 'sky_MEAN', 
                       'lst_day_c', 'lst_night_c', 'uhi_day_c', 'uhi_night_c', 'Land505', 
                       'railway_m']  # 将要删除的列名放在这里
    # 删除指定的列
    df = df.drop(columns=columns_to_drop)
    # 删除'nighttime_light_dnb'列中值为'<空>'的所有行
    df = df[df['nighttime_light_dnb'] != '<空>']
    # 删除'不透水度'列中值为'<空>'的所有行
    df = df[df['不透水面比例'] != '<空>']
    # 删除'NDVI_MEAN'列中值为'<空>'的所有行
    df = df[df['NDVI_MEAN'] != '<空>']
    # 将所有的'<空>'替换成0
    df = df.replace('<空>', 0)

    # 添加"平均建筑高度"列
    df['平均建筑高度'] = df.apply(lambda row: row['容积率'] / row['建筑密度'] if row['建筑密度'] != 0 else 0, axis=1)

    # 添加"POI总数"列，加总所有POI设施数量
    poi_columns = ['POI餐饮服务_n', 'POI公司企业_n', 'POI购物服务_n', 'POI科教文化_n', 'POI商务住宅_n', 
                   'POI生活服务_n', 'POI体育休闲_n', 'POI医疗保健_n', 'POI政府机构团体_n', 'POI风景名胜_n']
    df['POI总数'] = df[poi_columns].sum(axis=1)

    # 将第一行的列名以及坐标信息作为返回
    ids = df['OBJECTID'].values
    features_df = df.drop(columns=['OBJECTID', 'nighttime_light_dnb'])
    features = features_df.values  # 除去'nighttime_light_dnb'列的其他列作为模型输入的特征
    labels = df['nighttime_light_dnb'].values  # 'light_dnb'列作为标签(要预测的y)
    feature_names = list(features_df.columns)
    return features, labels, ids, feature_names

# 加载和构建预测平均地表温度数据集的预处理函数
def excel_predict_lst_filter(file_name, time = "day"):
    df = pd.read_excel(file_name)

    # 添加"POI总数"列，加总所有POI设施数量
    poi_columns = ['POI餐饮服务_n', 'POI公司企业_n', 'POI购物服务_n', 'POI科教文化_n', 'POI商务住宅_n', 
                   'POI生活服务_n', 'POI体育休闲_n', 'POI医疗保健_n', 'POI政府机构团体_n', 'POI风景名胜_n']
    df['POI总数'] = df[poi_columns].sum(axis=1)

    # 删除'lst_day_c'列中值为'<空>'的所有行
    df = df[df['lst_day_c'] != '<空>']

    if time == "day":
        # 删除sidewalk_MEAN building_MEAN vegetation_MEAN sky_MEAN(街景数据量不足) nighttime_light_dnb lst_night_c uhi_day_c uhi_night_c(暂不作为预测指标)
        # 根据相关性分析 公园绿地用地占比与昼间平均地表温度相关性极低 不作为输入
        columns_to_drop = ['sidewalk_MEAN', 'building_MEAN', 'vegetation_MEAN', 'sky_MEAN', 
                          'nighttime_light_dnb', 'lst_night_c', 'uhi_day_c', 'uhi_night_c', 
                          'Land505']  # 将要删除的列名放在这里
    else:
        # 删除sidewalk_MEAN building_MEAN vegetation_MEAN sky_MEAN(街景数据量不足) nighttime_light_dnb lst_day_c uhi_day_c uhi_night_c(暂不作为预测指标)
        # 根据相关性分析 公园绿地用地占比、工业用地占比、栅格内铁路长度与夜间平均地表温度相关性极低 不作为输入
        columns_to_drop = ['sidewalk_MEAN', 'building_MEAN', 'vegetation_MEAN', 'sky_MEAN', 
                          'nighttime_light_dnb', 'lst_day_c', 'uhi_day_c', 'uhi_night_c', 
                          'Land505', 'Land03', 'railway_m']  # 将要删除的列名放在这里
    
    # 删除指定的列
    df = df.drop(columns=columns_to_drop)
    # 删除'不透水度'列中值为'<空>'的所有行
    df = df[df['不透水面比例'] != '<空>']
    # 删除'NDVI_MEAN'列中值为'<空>'的所有行
    df = df[df['NDVI_MEAN'] != '<空>']
    # 将所有的'<空>'替换成0
    df = df.replace('<空>', 0)

    # 添加"平均建筑高度"列
    df['平均建筑高度'] = df.apply(lambda row: row['容积率'] / row['建筑密度'] if row['建筑密度'] != 0 else 0, axis=1)

    # 将第一行的列名作为标签
    ids = df['OBJECTID'].values

    if time == "day":
        features_df = df.drop(columns=['OBJECTID', 'lst_day_c'])
        features = features_df.values  # 除去'lst_day_c'列的其他列作为模型输入的特征
        labels = df['lst_day_c'].values  # 'lst_day_c'列作为标签(要预测的y)
        feature_names = list(features_df.columns)
    else:
        features_df = df.drop(columns=['OBJECTID', 'lst_night_c'])
        features = features_df.values  # 除去'lst_night_c'列的其他列作为模型输入的特征
        labels = df['lst_night_c'].values  # 'lst_night_c'列作为标签(要预测的y)
        feature_names = list(features_df.columns)
    return features, labels, ids, feature_names

# 加载和构建预测热岛效应数据集的预处理函数
def excel_predict_uhi_filter(file_name, time = "day"):
    df = pd.read_excel(file_name)

    # 添加"POI总数"列，加总所有POI设施数量
    poi_columns = ['POI餐饮服务_n', 'POI公司企业_n', 'POI购物服务_n', 'POI科教文化_n', 'POI商务住宅_n', 
                   'POI生活服务_n', 'POI体育休闲_n', 'POI医疗保健_n', 'POI政府机构团体_n', 'POI风景名胜_n']
    df['POI总数'] = df[poi_columns].sum(axis=1)

    # 删除'uhi_day_c'列中值为'<空>'的所有行
    df = df[df['uhi_day_c'] != '<空>']

    if time == "day":
        # 删除sidewalk_MEAN building_MEAN vegetation_MEAN sky_MEAN(街景数据量不足) nighttime_light_dnb lst_day_c lst_night_c uhi_night_c(暂不作为预测指标)
        columns_to_drop = ['sidewalk_MEAN', 'building_MEAN', 'vegetation_MEAN', 'sky_MEAN', 
                          'nighttime_light_dnb', 'lst_day_c', 'lst_night_c', 'uhi_night_c']  # 将要删除的列名放在这里
    else:
        # 删除sidewalk_MEAN building_MEAN vegetation_MEAN sky_MEAN(街景数据量不足) nighttime_light_dnb lst_day_c lst_night_c uhi_day_c(暂不作为预测指标)
        columns_to_drop = ['sidewalk_MEAN', 'building_MEAN', 'vegetation_MEAN', 'sky_MEAN', 
                          'nighttime_light_dnb', 'lst_day_c', 'lst_night_c', 'uhi_day_c']  # 将要删除的列名放在这里
    
    # 删除指定的列
    df = df.drop(columns=columns_to_drop)
    # 删除'不透水度'列中值为'<空>'的所有行
    df = df[df['不透水面比例'] != '<空>']
    # 删除'NDVI_MEAN'列中值为'<空>'的所有行
    df = df[df['NDVI_MEAN'] != '<空>']
    # 将所有的'<空>'替换成0
    df = df.replace('<空>', 0)

    # 添加"平均建筑高度"列
    df['平均建筑高度'] = df.apply(lambda row: row['容积率'] / row['建筑密度'] if row['建筑密度'] != 0 else 0, axis=1)

    # 将第一行的列名作为标签
    ids = df['OBJECTID'].values

    if time == "day":
        features_df = df.drop(columns=['OBJECTID', 'uhi_day_c'])
        features = features_df.values  # 除去'uhi_day_c'列的其他列作为模型输入的特征
        labels = df['uhi_day_c'].values  # 'uhi_day_c'列作为标签(要预测的y)
        feature_names = list(features_df.columns)
    else:
        features_df = df.drop(columns=['OBJECTID', 'uhi_night_c'])
        features = features_df.values  # 除去'uhi_night_c'列的其他列作为模型输入的特征
        labels = df['uhi_night_c'].values  # 'uhi_night_c'列作为标签(要预测的y)
        feature_names = list(features_df.columns)
    return features, labels, ids, feature_names

# 构建 CityDataSet
class CityDataSet(Dataset):
    def __init__(self, features, labels):
        self.features = features.clone().detach().float()
        self.labels = labels.clone().detach().float()
    
    def __len__(self):
        return len(self.features)
    
    def __getitem__(self, index):
        return self.features[index], self.labels[index]
    

def data_filter(data_file, predict_target):
    if predict_target == "light":
        return excel_predict_light_filter(data_file)
    elif predict_target == "lst_day":
        return excel_predict_lst_filter(data_file, time="day")
    elif predict_target == "lst_night":
        return excel_predict_lst_filter(data_file, time="night")
    elif predict_target == "uhi_day":
        return excel_predict_uhi_filter(data_file, time="day")
    elif predict_target == "uhi_night":
        return excel_predict_uhi_filter(data_file, time="night")
    else:
        raise ValueError(f"错误的预测目标名称: {predict_target}")


# 生成十折交叉验证的数据集
def get_ten_fold_datasets(data_file, predict_target, random_seed=42):
    # 加载并处理数据
    features, labels, ids, feature_names = data_filter(data_file, predict_target)
    
    # 将数据转为 tensor
    features = torch.tensor(features, dtype=torch.float)
    labels = torch.tensor(labels, dtype=torch.float).unsqueeze(1)

    # 创建 CityDataSet 
    city_dataset = CityDataSet(features, labels)
    
    # 初始化 StratifiedKFold
    skf = StratifiedKFold(n_splits=10, shuffle=True, random_state=random_seed)

    # 创建离散标签，用于 StratifiedKFold 的分层分割
    stratify_labels = pd.qcut(labels.cpu().numpy().flatten(), q=10, labels=False)

     # 使用 StratifiedKFold 来获取五个不重叠的分组
    fold_indices = [test_idx for _, test_idx in skf.split(features.cpu(), stratify_labels)]

    return city_dataset, fold_indices, feature_names



<template>
  <div v-if="visible" class="modal-overlay">
    <div class="modal-content">
      <span class="close-button" @click="close">×</span>
      <form class="reset">
        <div class="reset-field">
          <input type="text" class="reset-input" placeholder="Email" v-model="form.email" />
        </div>
        <div class="error-text" v-if="emailError">{{ emailError }}</div>
        <div class="reset-field">
          <input type="text" class="reset-input" placeholder="Password" v-model="form.new_password" />
        </div>
        <div class="reset-field code-row">
          <input type="text" class="reset-input" placeholder="Email Code" v-model="form.verification_code" />
          <button type="button" class="code-button" @click="sendCode" :disabled="codeSending">
            {{ codeSending ? countdown + 's' : '获取验证码' }}
          </button>
        </div>
        <button type="button" class="button reset-submit">
          <span class="button-text"  @click="sendCodeReset">确定</span>
        </button>
      </form>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, defineProps, defineEmits, watch } from 'vue'
import { type PasswordReset } from '@/api/user/type';
import { resetSendCode, passwordReset } from '@/api/user';
import { ElMessage } from 'element-plus';
// prop传递注册组件是否显示
const props = defineProps<{ visible: boolean }>()
// 发送关闭事件
const emit = defineEmits(['close'])

const close = () => emit('close')

const form = ref<PasswordReset>({
  email: '',
  new_password: '',
  verification_code: '',
})

const codeSending = ref<boolean>(false)
const countdown = ref<number>(60)
let timer = null

const emailError = ref<string>('')  // 邮箱错误信息

const validateEmail = (email: string) => {
  const pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return pattern.test(email)
}

watch(() => form.value.email, (newVal) => {
  if (!newVal) {
    emailError.value = '请输入邮箱'
  } else if (!validateEmail(newVal)) {
    emailError.value = '邮箱格式不正确'
  } else {
    emailError.value = ''
  }
})

const sendCode = () => {
  if (!form.value.email) {
    ElMessage.warning('请输入邮箱')
    return
  }
  codeSending.value = true
  countdown.value = 60
  // 开始计时器
  timer = setInterval(() => {
    countdown.value--
    if (countdown.value <= 0) {
      clearInterval(timer)
      codeSending.value = false
    }
  }, 1000)
  console.log('发送验证码到邮箱:', form.value.email)
  resetSendCode({email: form.value.email}).then((data) => {
    console.log(data)
    if (data.code === 200){
      ElMessage({
        showClose: true,
        message: `验证码已发送至邮箱地址：${form.value.email}，有效期为10分钟`,
        type: 'success',
      })
    }
    else {
      console.warn(`请求地址：/api/v1/reset-password/send-code，状态码：${data.code}，错误信息：${data.message}`)
      ElMessage({
        showClose: true,
        message: data.message,
        type: 'error',
      })
    }
  })
}

const sendCodeReset = () => {
  if(form.value.email && form.value.new_password && form.value.verification_code && validateEmail(form.value.email)) {
    // 密码重置请求
    passwordReset(form.value).then((data) => {
      if(data.code === 200) {
        ElMessage({
          showClose: true,
          message: "密码重置成功，请尝试登录",
          type: 'success',
        })
        close()
      }
      else {
        console.warn(`请求地址：/api/v1/auth/register，状态码：${data.code}，错误信息：${data.message}`)
        ElMessage({
          showClose: true,
          message: data.message,
          type: 'error',
        })
      }
    })
    .catch(err => {
      console.warn(err) 
      ElMessage({
        showClose: true,
        message: "发生了一些错误，请稍后再试！",
        type: 'error',
      })
    })
  }
  else {
    ElMessage({
      showClose: true,
      message: "请完善表单内容",
      type: 'error',
    })
  }
}
</script>

<style scoped lang="scss">
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 999;
}

.modal-content {
  position: relative;
  width: 400px;
  padding: 40px 30px;
  background: linear-gradient(90deg, #5D54A4, #7C78B8);
  border-radius: 20px;
  box-shadow: 0 0 24px #5C5696;
}

.close-button {
  position: absolute;
  top: 10px;
  right: 16px;
  font-size: 24px;
  color: white;
  cursor: pointer;
}

.reset-field {
  padding: 20px 0;
}

.reset-input {
  border: none;
  border-bottom: 2px solid #D1D1D4;
  background: none;
  padding: 10px;
  padding-left: 10px;
  font-weight: 700;
  width: 100%;
  color: white;
  transition: .2s;
}

.reset-input:focus {
  outline: none;
  border-bottom-color: #fff;
}

.code-row {
  display: flex;
  justify-content: space-between;

  .reset-input {
    width: 60%;
  }

  .code-button {
    margin-left: 10px;
    padding: 10px 14px;
    background-color: #fff;
    color: #4C489D;
    font-weight: bold;
    border-radius: 20px;
    border: 1px solid #D4D3E8;
    cursor: pointer;
  }

  .code-button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }
}

.reset-submit {
  background: #fff;
  font-size: 14px;
  margin-top: 30px;
  padding: 14px 20px;
  border-radius: 26px;
  border: 1px solid #D4D3E8;
  font-weight: 700;
  width: 100%;
  color: #4C489D;
  cursor: pointer;
}

.error-text {
  color: #ffcccc;
  font-size: 12px;
  margin-top: 4px;
}
</style>

<template>
  <router-view></router-view>
</template>

<script setup lang="ts">

</script>

<style>
  html, body, #app {
    margin: 0px;
    padding: 0px;
  }
</style>

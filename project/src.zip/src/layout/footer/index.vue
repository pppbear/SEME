<template>
  <p>有问题请联系2252958@tongji.edu.cn</p>
</template>

<script setup lang="ts">

</script>

<style>

</style>